
/**
 * A SelectionSorter sorts arrays using the selection sort algorithm.
 */
public class SelectionSorter extends BaseSorter {

  /**
   * Sorts an array using the selection sort algorithm.
   * 
   * @param array
   */
  protected void doSort(double[] array) {
    // TODO: Implement this method.
  }

}
