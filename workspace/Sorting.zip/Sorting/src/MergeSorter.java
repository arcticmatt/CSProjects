/**
 * A MergeSorter sorts arrays using the merge sort algorithm.
 */
public class MergeSorter extends BaseSorter {

  /**
   * Sorts an array using the merge sort algorithm.
   * 
   * @param array The array to be sorted.
   */
  protected void doSort(double[] array) {
    // TODO: Implement this method.
  }

}
