3.5) In the absolute worst case, all the entries would be inside one bucket. In that case, we might have to examine
all entries to determine the value associated with a given key; it would run in O(n) time.
