/**
 * The base Exception class thrown when there's a game error and
 * somebody's disqualified.
 **/
abstract public class GameException extends Exception {}
