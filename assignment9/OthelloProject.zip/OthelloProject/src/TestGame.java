public class TestGame
{
   public static void main(String[] args)
   {

	  // Replace p1 and p2 with constructors for AIs you want to test.
      OthelloPlayer p1 = new SimplePlayer();
      OthelloPlayer p2 = new ConstantTimePlayer();
      OthelloObserver o = new OthelloDisplay();

      //Uncomment this if you want to play against an AI as White.
      //OthelloPlayer o2 = new OthelloDisplay();
      //OthelloGame g = new OthelloGame(p1, o2, o);
      
      //Uncomment this if you want to play against an AI as black.
      //OthelloPlayer o2 = new OthelloDisplay();
      //OthelloGame g = new OthelloGame(o2, p1, o);
      
      //Comment this if playing against an AI.
      //By default, we put two AIs against each other.
      OthelloGame g = new OthelloGame(p1, p2, o);
      
      System.out.println("Starting game");
      g.run();
   }
}
