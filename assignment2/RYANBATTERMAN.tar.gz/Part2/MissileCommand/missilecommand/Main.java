/*
 * Main.java
 *
 * Created on January 9, 2006, 3:58 PM
 *
 */

package missilecommand;

/**
 *
 * @author janice 
 */
public class Main {

  /** Creates a new instance of Main */
  public Main() {
  }

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO code application logic here
    MissileCommandApplication ignored = new MissileCommandApplication();
  }

}
